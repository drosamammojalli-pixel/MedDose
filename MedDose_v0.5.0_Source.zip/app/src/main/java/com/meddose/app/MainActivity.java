package com.meddose.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int navy=Color.rgb(20,43,66), teal=Color.rgb(0,132,139), bg=Color.rgb(245,248,250), ink=Color.rgb(35,49,63), muted=Color.rgb(105,121,135), line=Color.rgb(225,232,237), white=Color.WHITE;
    private LinearLayout root, body, listArea;
    private JSONArray drugs=new JSONArray();
    private String activeCategory="All", query="";
    private boolean favoritesOnly=false;
    private android.content.SharedPreferences prefs;
    private EditText search;
    private TextView countLabel;

    @Override public void onCreate(Bundle state){super.onCreate(state); getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(bg); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); prefs=getSharedPreferences("meddose",MODE_PRIVATE); loadData(); home();}
    private void loadData(){try(InputStream is=getAssets().open("drugs.json")){byte[] b=new byte[is.available()]; is.read(b); drugs=new JSONArray(new String(b,"UTF-8"));}catch(Exception ignored){}}
    private GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setIncludeFontPadding(true);return t;}
    private void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}
    private void frame(String title,boolean back){root=column();root.setBackgroundColor(bg);LinearLayout top=row();top.setBackgroundColor(navy);pad(top,18,15,18,15);
        if(back){TextView b=text("‹",34,white,false);b.setGravity(Gravity.CENTER);top.addView(b,new LinearLayout.LayoutParams(dp(38),dp(42)));b.setOnClickListener(v->home());}
        LinearLayout brand=column();TextView name=text("MedDose",22,white,true);TextView sub=text(title,11,0xFFB9D6DF,false);brand.addView(name);brand.addView(sub);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView mark=text("✚",23,0xFF8DE0D5,true);mark.setGravity(Gravity.CENTER);mark.setBackground(shape(0xFF244F68,14,0));top.addView(mark,new LinearLayout.LayoutParams(dp(42),dp(42)));
        root.addView(top);ScrollView sc=new ScrollView(this);sc.setFillViewport(true);body=column();pad(body,16,16,16,28);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    private void home(){frame("CLINICAL DRUG REFERENCE  •  OFFLINE",false);
        LinearLayout hero=column();hero.setBackground(shape(navy,22,0));pad(hero,18,18,18,18);
        TextView eyebrow=text("YOUR POCKET DRUG DESK",10,0xFF8EDBD2,true);hero.addView(eyebrow);
        TextView headline=text("Find the right\nmedicine information.",25,white,true);pad(headline,0,7,0,5);hero.addView(headline);
        hero.addView(text("Search the library by generic name or browse by clinical category.",13,0xFFD4E2EA,false));
        LinearLayout stats=row();pad(stats,0,16,0,0);stats.addView(stat(String.valueOf(drugs.length()),"MEDICINES"),new LinearLayout.LayoutParams(0,-2,1));stats.addView(stat("4","CALCULATORS"),new LinearLayout.LayoutParams(0,-2,1));stats.addView(stat("OFFLINE","ACCESS"),new LinearLayout.LayoutParams(0,-2,1));hero.addView(stats);body.addView(hero);
        LinearLayout shortcuts=row();TextView calcShortcut=text("▦   Clinical calculators  ›",14,teal,true);pad(calcShortcut,14,13,14,13);calcShortcut.setBackground(shape(white,14,line));shortcuts.addView(calcShortcut,new LinearLayout.LayoutParams(-1,-2));calcShortcut.setOnClickListener(v->calculators());LinearLayout.LayoutParams sh=new LinearLayout.LayoutParams(-1,-2);sh.topMargin=dp(10);body.addView(shortcuts,sh);
        search=new EditText(this);search.setSingleLine(true);search.setTextSize(15);search.setHint("⌕   Search generic or brand name");search.setHintTextColor(muted);search.setTextColor(ink);search.setBackground(shape(white,15,line));pad(search,15,5,15,5);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(54));sp.topMargin=dp(16);body.addView(search,sp);
        TextView cats=text("BROWSE CATEGORIES",11,muted,true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(20);body.addView(cats,cp);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout chips=row();String[] categories={"All","Cardiovascular","Antibiotics","Emergency","Endocrine","Respiratory","GI","Neurology","Analgesia","Other"};for(String c:categories){TextView chip=text(c,12,activeCategory.equals(c)?white:ink,true);pad(chip,14,9,14,9);chip.setBackground(shape(activeCategory.equals(c)?teal:white,30,activeCategory.equals(c)?teal:line));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.rightMargin=dp(7);chips.addView(chip,p);chip.setOnClickListener(v->{activeCategory=c;home();});}hsv.addView(chips);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(10);body.addView(hsv);
        LinearLayout heading=row();TextView h=text("Medicine library",19,ink,true);heading.addView(h,new LinearLayout.LayoutParams(0,-2,1));countLabel=text(drugs.length()+" entries",11,muted,false);heading.addView(countLabel);LinearLayout.LayoutParams hdp=new LinearLayout.LayoutParams(-1,-2);hdp.topMargin=dp(22);body.addView(heading,hdp);
        Button favFilter=actionButton(favoritesOnly?"♥  Showing favorites  ·  tap for all":"♡  Show favorites");favFilter.setTextSize(12);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(42));fp.topMargin=dp(8);body.addView(favFilter,fp);favFilter.setOnClickListener(v->{favoritesOnly=!favoritesOnly;home();});
        String recent=prefs.getString("recent","");
        if(!recent.isEmpty()&&!favoritesOnly){TextView recentTitle=text("RECENTLY VIEWED",10,muted,true);LinearLayout.LayoutParams rtp=new LinearLayout.LayoutParams(-1,-2);rtp.topMargin=dp(12);body.addView(recentTitle,rtp);LinearLayout recentRow=row();for(String recentName:recent.split("\\|")){for(int j=0;j<drugs.length();j++){JSONObject rd=drugs.optJSONObject(j);if(rd!=null&&rd.optString("name").equals(recentName)){TextView chip=text(recentName,11,teal,true);pad(chip,10,7,10,7);chip.setBackground(shape(white,18,line));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-2,-2);rp.rightMargin=dp(6);recentRow.addView(chip,rp);chip.setOnClickListener(v->detail(rd));break;}}}HorizontalScrollView recentScroll=new HorizontalScrollView(this);recentScroll.setHorizontalScrollBarEnabled(false);recentScroll.addView(recentRow);body.addView(recentScroll);}
        listArea=column();body.addView(listArea);renderList("");search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int c){query=s.toString();renderList(query);}public void afterTextChanged(Editable e){}});
        TextView note=text("CLINICAL SAFETY  •  This build contains a 50-medicine index and working calculators. Indication-specific dosing content is not yet clinically verified or complete. Do NOT use it as a prescribing reference. Check current product information and local protocols.",11,0xFF8A4B25,false);pad(note,13,12,13,12);note.setBackground(shape(0xFFFFF3E7,13,0xFFF1D5B9));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(18);body.addView(note);
    }
    private EditText calcField(String hint){
        EditText e=new EditText(this);
        e.setSingleLine(true); e.setTextSize(14); e.setHint(hint); e.setHintTextColor(muted);
        e.setTextColor(ink); e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setBackground(shape(white,12,line)); pad(e,12,5,12,5);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50)); p.topMargin=dp(8); body.addView(e,p); return e;
    }
    private double number(EditText e){
        if(e==null)return Double.NaN;
        try { String x=e.getText().toString().trim().replace(',','.'); if(x.isEmpty())return Double.NaN; double v=Double.parseDouble(x); return (!Double.isNaN(v)&&!Double.isInfinite(v))?v:Double.NaN; }
        catch(Exception ex){return Double.NaN;}
    }
    private void calculators(){
        try {
            frame("CLINICAL CALCULATORS",true);
            TextView intro=text("Four practical arithmetic tools. Results do not establish that a prescribed regimen is clinically appropriate.",13,muted,false); body.addView(intro);
            calculatorSection("1 · WEIGHT-BASED DOSE", "Prescribed dose (mg/kg/dose) × weight (kg). Maximum dose is an optional independent ceiling.");
            EditText w=calcField("Weight (kg)"), dose=calcField("Prescribed dose (mg/kg/dose)"), max=calcField("Optional maximum dose (mg)");
            TextView doseOut=text("",15,ink,true); body.addView(doseOut); Button doseBtn=actionButton("Calculate dose"); body.addView(doseBtn);
            doseBtn.setOnClickListener(v->{double a=number(w),b=number(dose),m=max.getText().toString().trim().isEmpty()?Double.NaN:number(max); if(!(a>0&&b>0)||(!Double.isNaN(m)&&m<=0)){doseOut.setText("Check inputs: weight and dose must be positive; maximum must be positive or blank.");return;} double raw=a*b, result=Double.isNaN(m)?raw:Math.min(raw,m);doseOut.setText(String.format(Locale.US,"Calculated dose: %.2f mg%s",result,(!Double.isNaN(m)&&raw>m)?" (limited by entered maximum)":""));});

            calculatorSection("2 · IV INFUSION RATE", "mL/hour = total volume (mL) ÷ duration (hours).");
            EditText vol=calcField("Total volume (mL)"), hrs=calcField("Duration (hours)"); TextView infOut=text("",15,ink,true);body.addView(infOut);Button infBtn=actionButton("Calculate mL/hour");body.addView(infBtn);
            infBtn.setOnClickListener(v->{double a=number(vol),b=number(hrs);if(!(a>0&&b>0)){infOut.setText("Enter a positive volume and duration.");return;}infOut.setText(String.format(Locale.US,"Infusion rate: %.2f mL/hour",a/b));});

            calculatorSection("3 · GRAVITY DRIP RATE", "Drops/min = volume (mL) × giving-set factor (drops/mL) ÷ time (minutes).");
            EditText gv=calcField("Volume (mL)"), gh=calcField("Duration (hours)"), gf=calcField("Drop factor (10, 15, 20 or 60 drops/mL)");TextView dripOut=text("",15,ink,true);body.addView(dripOut);Button dripBtn=actionButton("Calculate drops/min");body.addView(dripBtn);
            dripBtn.setOnClickListener(v->{double a=number(gv),b=number(gh),c=number(gf);if(!(a>0&&b>0&&c>0)){dripOut.setText("Enter positive volume, duration and drop factor.");return;}dripOut.setText(String.format(Locale.US,"Rate: %.2f mL/hour  ·  %d drops/min",a/b,Math.round(a*c/(b*60.0))));});

            calculatorSection("4 · PREPARATION / CONCENTRATION", "Concentration = drug amount ÷ final volume. Volume to withdraw = required dose ÷ concentration.");
            EditText amount=calcField("Drug amount in vial (mg)"), finalVol=calcField("Final volume after dilution (mL)"), required=calcField("Required dose (mg)");TextView prepOut=text("",15,ink,true);body.addView(prepOut);Button prepBtn=actionButton("Calculate concentration and volume");body.addView(prepBtn);
            prepBtn.setOnClickListener(v->{double a=number(amount),b=number(finalVol),c=number(required);if(!(a>0&&b>0&&c>0)){prepOut.setText("Enter positive drug amount, final volume and required dose.");return;}double concentration=a/b,withdraw=c/concentration;if(withdraw>b){prepOut.setText(String.format(Locale.US,"Concentration: %.3f mg/mL. Required volume %.2f mL exceeds the entered final volume; recheck the dose and preparation.",concentration,withdraw));}else{prepOut.setText(String.format(Locale.US,"Concentration: %.3f mg/mL\nVolume to withdraw: %.2f mL",concentration,withdraw));}});

            TextView warning=text("SAFETY: Arithmetic only. Confirm the medicine, indication, prescribed dose, maximum, units, formulation, compatibility, diluent, final concentration, route and infusion duration using an authoritative current reference and local protocol. Do not use this tool to select a regimen.",12,0xFF8A4B25,false);pad(warning,13,12,13,12);warning.setBackground(shape(0xFFFFF3E7,13,0xFFF1D5B9));LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,-2);wp.topMargin=dp(20);body.addView(warning,wp);
        } catch(Exception ex) {
            Toast.makeText(this,"Calculator screen error. Please return home and reopen it.",Toast.LENGTH_LONG).show();
            home();
        }
    }
    private void calculatorSection(String title,String description){TextView h=text(title,12,teal,true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(22);body.addView(h,hp);TextView d=text(description,13,muted,false);LinearLayout.LayoutParams dp0=new LinearLayout.LayoutParams(-1,-2);dp0.topMargin=dp(4);body.addView(d,dp0);}
    private Button actionButton(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(white);b.setBackground(shape(teal,14,0));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.topMargin=dp(10);b.setLayoutParams(p);return b;}

    private View stat(String value,String label){LinearLayout l=column();TextView v=text(value,18,white,true);TextView t=text(label,9,0xFFB9D6DF,true);l.addView(v);l.addView(t);return l;}
    private String categoryIcon(String c){String x=c.toLowerCase(Locale.US);if(x.contains("cardio"))return "♥";if(x.contains("antibiotic"))return "✚";if(x.contains("emergency"))return "⚡";if(x.contains("endocr"))return "◉";if(x.contains("respir"))return "◌";if(x.contains("gastro")||x.equals("gi"))return "◒";if(x.contains("neuro"))return "⌁";if(x.contains("analges"))return "✳";return "＋";}
    private void renderList(String q){if(listArea==null)return;listArea.removeAllViews();int shown=0;for(int i=0;i<drugs.length();i++){JSONObject d=drugs.optJSONObject(i);if(d==null)continue;String n=d.optString("name"),c=d.optString("category");if(!n.toLowerCase(Locale.US).contains(q.toLowerCase(Locale.US))&&!c.toLowerCase(Locale.US).contains(q.toLowerCase(Locale.US)))continue;if(!activeCategory.equals("All")&&!categoryMatches(c,activeCategory))continue;if(favoritesOnly&&!isFavorite(n))continue;shown++;listArea.addView(drugCard(d));}countLabel.setText(shown+" shown");if(shown==0){TextView empty=text(favoritesOnly?"No favorites yet. Open a medicine and tap the heart to save it.":"No medicines match your search. Try another name or category.",14,muted,false);pad(empty,10,22,10,22);listArea.addView(empty);}}
    private boolean categoryMatches(String actual,String filter){String a=actual.toLowerCase(Locale.US),f=filter.toLowerCase(Locale.US);if(f.equals("gi"))return a.contains("gastro")||a.contains("hepato");if(f.equals("analgesia"))return a.contains("analges")||a.contains("pain");return a.contains(f);}
    private View drugCard(JSONObject d){LinearLayout card=row();card.setBackground(shape(white,16,line));pad(card,13,12,13,12);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);card.setLayoutParams(p);
        TextView icon=text(categoryIcon(d.optString("category")),21,teal,true);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(0xFFE8F4F4,13,0));card.addView(icon,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout info=column();pad(info,12,0,0,0);TextView n=text(d.optString("name"),15,ink,true);info.addView(n);TextView cat=text(d.optString("category"),11,muted,false);info.addView(cat);TextView status=text(d.optBoolean("reviewed",false)?"VERIFIED MONOGRAPH":"MONOGRAPH IN DEVELOPMENT",9,d.optBoolean("reviewed",false)?0xFF28765D:0xFF9A682B,true);pad(status,0,4,0,0);info.addView(status);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=text("›",27,muted,false);card.addView(arrow);card.setOnClickListener(v->detail(d));return card;}
    private boolean isFavorite(String name){return prefs.getStringSet("favorites",new HashSet<>()).contains(name);}
    private void toggleFavorite(String name){Set<String> set=new HashSet<>(prefs.getStringSet("favorites",new HashSet<>()));if(set.contains(name))set.remove(name);else set.add(name);prefs.edit().putStringSet("favorites",set).apply();}
    private void saveRecent(String name){String old=prefs.getString("recent","");ArrayList<String> items=new ArrayList<>();items.add(name);for(String x:old.split("\\|")){if(!x.isEmpty()&&!x.equals(name)&&items.size()<6)items.add(x);}StringBuilder b=new StringBuilder();for(String x:items){if(b.length()>0)b.append('|');b.append(x);}prefs.edit().putString("recent",b.toString()).apply();}
    private void detail(JSONObject d){saveRecent(d.optString("name"));frame(d.optString("category").toUpperCase(Locale.US),true);TextView title=text(d.optString("name"),27,ink,true);body.addView(title);
        Button fav=actionButton(isFavorite(d.optString("name"))?"♥  Remove from favorites":"♡  Add to favorites");fav.setTextSize(12);LinearLayout.LayoutParams fvp=new LinearLayout.LayoutParams(-1,dp(42));fvp.topMargin=dp(8);body.addView(fav,fvp);fav.setOnClickListener(v->{toggleFavorite(d.optString("name"));fav.setText(isFavorite(d.optString("name"))?"♥  Remove from favorites":"♡  Add to favorites");});TextView sub=text(d.optString("summary"),14,muted,false);pad(sub,0,5,0,14);body.addView(sub);
        JSONArray inds=d.optJSONArray("indications");TextView section=text("INDICATION-SPECIFIC DOSING",12,teal,true);pad(section,0,10,0,8);body.addView(section);
        if(inds==null||inds.length()==0){LinearLayout empty=column();empty.setBackground(shape(white,16,line));pad(empty,15,15,15,15);empty.addView(text("No verified dosing regimens have been added yet.",15,ink,true));TextView msg=text("This medicine is indexed for search, but its indication-by-indication adult and pediatric doses are not yet clinically verified. No dose has been guessed or generated. Check an up-to-date licensed reference before prescribing.",13,muted,false);pad(msg,0,8,0,0);empty.addView(msg);body.addView(empty);}else{for(int i=0;i<inds.length();i++){JSONObject ind=inds.optJSONObject(i);if(ind!=null)body.addView(indicationCard(ind));}}
        infoSection("Clinical notes",d.optString("notes","No additional notes entered."));infoSection("Source & review",d.optString("source","Source not yet attached" )+"\n"+d.optString("reviewStatus","Awaiting clinical review"));
        TextView safety=text("SAFETY: Verify indication, formulation, route, frequency, maximum dose, duration, interactions, contraindications and organ-function adjustments against a current authoritative reference and local protocol.",11,0xFF8A4B25,false);pad(safety,13,12,13,12);safety.setBackground(shape(0xFFFFF3E7,13,0xFFF1D5B9));body.addView(safety);
    }
    private View indicationCard(JSONObject ind){LinearLayout c=column();c.setBackground(shape(white,15,line));pad(c,14,13,14,13);TextView h=text(ind.optString("indication"),16,ink,true);c.addView(h);String[] keys={"adult","pediatric","route","frequency","maximum","duration","adjustments","administration","source","referenceEdition","reviewDate"};String[] labels={"ADULTS","CHILDREN","ROUTE","FREQUENCY","MAXIMUM","DURATION","RENAL / HEPATIC","ADMINISTRATION","SOURCE","EDITION / SECTION","REVIEWED"};for(int i=0;i<keys.length;i++){String value=ind.optString(keys[i],"");if(!value.isEmpty()){TextView t=text(labels[i]+"  ·  "+value,12,muted,false);pad(t,0,7,0,0);c.addView(t);}}return c;}
    private void infoSection(String title,String value){TextView h=text(title,15,ink,true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(18);body.addView(h,p);TextView v=text(value,13,muted,false);pad(v,13,12,13,12);v.setBackground(shape(white,13,line));LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,-2);vp.topMargin=dp(7);body.addView(v,vp);}
}
