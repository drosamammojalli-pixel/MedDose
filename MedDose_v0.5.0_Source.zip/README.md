# MedDose Android — v0.5.0

Offline native Android medicine-reference shell with a 50-medicine catalogue and four arithmetic calculators.

## Current features
- Offline generic-name medicine catalogue (50 entries)
- Search and clinical-category filters
- Favorites saved locally on the device
- Four calculators: mg/kg dose with optional cap, IV mL/hour, gravity drops/min, and concentration/withdrawal volume
- Drug detail pages with indication-specific structured fields ready for clinically reviewed content
- No internet permission; the app works offline

## Important clinical-content status
This build is **not a prescribing reference**. The 52 medicines are catalogue entries only. Indication-specific adult and pediatric dosing, preparation instructions, contraindications, interactions, and renal/hepatic adjustments have **not yet been clinically verified and are intentionally withheld**. The app must not be used to select or administer a dose.

The intended content sources are Medscape and Drugs.com. Each regimen must be checked against the current source/product information, with a source URL, review date, reviewer, indication, population, route, frequency, maximum, duration, and relevant adjustments before being marked reviewed. Neonatal dosing is outside project scope.

## Build APK using GitHub Actions (phone-friendly)
1. Upload the contents of this project folder to the root of your GitHub repository (not the ZIP archive itself).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build MedDose APK** and run it, or let the push trigger it.
5. Open the completed workflow run and download the artifact named `MedDose-v0.5.0-debug-apk`.
6. Extract the artifact ZIP; install `app-debug.apk` on Android. Allow installation from the browser/files app if Android asks.

## Technical
- Native Java Android app
- Application ID: `com.meddose.app`
- Minimum Android: API 23 (Android 6.0)
- Compile/target SDK: 35
- Build: Gradle 8.9, Android Gradle Plugin 8.7.3, JDK 17

## Updating the medicine content
Edit `app/src/main/assets/drugs.json`. Do not set `reviewed: true` unless every included regimen has undergone clinical verification. Empty `indications` arrays are deliberate and safer than guessed dosing.


## v0.5.0 medicine content status
15 medicine entries now contain initial adult and pediatric dosing drafts with source links to Drugs.com professional dosage guides. These are explicitly marked NOT clinically reviewed; verify indication-specific regimens, local resistance guidance, formulation and patient factors before prescribing. The remaining 35 catalogue entries still have no dosing. Neonatal dosing remains excluded.


## v0.5.0 medicine content status
15 medicine entries now contain initial adult and pediatric dosing drafts with source links to Drugs.com professional dosage guides. These are explicitly marked NOT clinically reviewed; verify indication-specific regimens, local resistance guidance, formulation and patient factors before prescribing. The remaining 35 catalogue entries still have no dosing. Neonatal dosing remains excluded.


## v0.5.0 medicine content status
15 medicine entries now contain initial adult and pediatric dosing drafts with source links to Drugs.com professional dosage guides. These are explicitly marked NOT clinically reviewed; verify indication-specific regimens, local resistance guidance, formulation and patient factors before prescribing. The remaining 35 catalogue entries still have no dosing. Neonatal dosing remains excluded.
