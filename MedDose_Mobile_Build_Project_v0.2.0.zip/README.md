# MedDose — Android clinical drug reference

## This build
- Native Android app (Java; no third-party runtime libraries).
- Redesigned home screen with a calm navy/teal palette, medicine cards, category browsing, search, and a custom medical launcher icon.
- 260 medicine entries in the offline searchable index.
- Dedicated monograph screen with an indication-by-indication dosing layout.
- Adult and pediatric fields only. Neonatal dosing is intentionally excluded.
- Retained IV gravity flow-rate and weight-based arithmetic calculators, restyled to match the new interface.

## Important clinical status
**This is a development build, not a clinically validated formulary and not for prescribing or patient-care decisions.** The 260 records are an index/catalogue. Their indication-specific adult and pediatric dosing regimens have not yet been populated and clinically verified. The app intentionally displays that status rather than inventing doses or presenting generic placeholders as prescribing instructions.

Each indication should be added as its own structured regimen, including:
- Indication and population (adult / child)
- Dose, units, route, interval and duration
- Maximum single and daily dose
- Weight/age limits where relevant
- Renal and hepatic adjustments
- Preparation, dilution, administration rate and monitoring where relevant
- Exact source, edition/version, section, access/review date and reviewer

A regimen must not be marked reviewed until the dose and all relevant restrictions have been checked against an authoritative, current source and local protocol. Proprietary references such as BNF, Lexicomp and Micromedex must not be copied into an offline product without appropriate licensing.

## Evidence and formulary selection
Use the current WHO Model List of Essential Medicines and the WHO Model List for Children as selection references, then verify each regimen against current national/institutional guidance and licensed drug references. WHO's current model lists were updated in September 2025. The app must remain explicit about source edition and review date because recommendations change.

## Build
1. Open this folder in Android Studio.
2. Use JDK 17, Android Gradle Plugin 8.7.3, Gradle 8.9, and Android SDK platform/build-tools 35.
3. Build `:app:assembleDebug`, or push to GitHub and run the included **Build MedDose APK** workflow.
4. The workflow uploads `app-debug.apk` as the `MedDose-debug-apk` artifact.

## Next development stages
1. Populate and clinically review the indication-specific dosing monographs in batches.
2. Add favourites, recently viewed medicines, and an improved filter system.
3. Restore and expand the calculators (dose, infusion, dilution, corrected electrolytes) with validation and unit safeguards.
4. Add database versioning, offline update/import support, and a formal clinical review process.
5. Test accessibility, small screens, tablets, and real devices before any release.
