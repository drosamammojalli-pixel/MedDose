package com.meddose.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout root, content;
    EditText search;
    JSONArray drugs = new JSONArray();
    ArrayList<JSONObject> filtered = new ArrayList<>();
    int ink = 0xFF17324D, teal = 0xFF087E8B, pale = 0xFFF3F7FA;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            InputStream is = getAssets().open("drugs.json");
            byte[] data = new byte[is.available()]; is.read(data); is.close();
            drugs = new JSONArray(new String(data, "UTF-8"));
        } catch (Exception ignored) {}
        buildHome();
    }

    TextView label(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(ink); if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 8, 0, 8); return t;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(pale);
        TextView top = new TextView(this); top.setText(title); top.setTextSize(22); top.setTypeface(null, Typeface.BOLD);
        top.setTextColor(-1); top.setBackgroundColor(ink); top.setPadding(18,18,18,18);
        root.addView(top);
        ScrollView sc = new ScrollView(this); content = new LinearLayout(this); content.setPadding(16,12,16,24);
        content.setOrientation(LinearLayout.VERTICAL); sc.addView(content); root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void buildHome() {
        base("MedDose  |  Clinical Drug Reference");
        content.addView(label("Offline clinical reference prototype", 14, false));
        content.addView(label("Search medicines", 18, true));
        search = new EditText(this); search.setSingleLine(true); search.setHint("Generic or brand name");
        content.addView(search);
        LinearLayout nav = new LinearLayout(this);
        Button drugsBtn = button("Drug library"), calcBtn = button("Calculators");
        nav.addView(drugsBtn, new LinearLayout.LayoutParams(0,-2,1)); nav.addView(calcBtn, new LinearLayout.LayoutParams(0,-2,1));
        content.addView(nav);
        content.addView(label("Browse common examples", 18, true));
        renderDrugs("");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ renderDrugs(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
        drugsBtn.setOnClickListener(v -> buildHome());
        calcBtn.setOnClickListener(v -> showCalculators());
        TextView warning = label("SAFETY NOTICE: This prototype contains a small demonstration dataset, not a complete or clinically validated formulary. Verify every prescription against current, licensed references and local protocols. Do not use this prototype for patient care.", 13, true);
        warning.setTextColor(0xFF9B2226); content.addView(warning);
    }
    void renderDrugs(String q) {
        if (content == null) return;
        // Keep search controls and redraw result area after first three children.
        while (content.getChildCount() > 3) content.removeViewAt(3);
        for (int i=0;i<drugs.length();i++) {
            JSONObject d=drugs.optJSONObject(i); if(d==null) continue;
            String n=d.optString("name");
            if (!n.toLowerCase(Locale.US).contains(q.toLowerCase(Locale.US))) continue;
            Button item=button(n+"  ›");
            item.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
            item.setOnClickListener(v -> showDrug(d));
            content.addView(item);
        }
    }
    void showDrug(JSONObject d) {
        base(d.optString("name"));
        content.addView(label(d.optString("category"),14,true));
        section("At a glance", d.optString("practical"));
        section("Adult dosing", d.optString("adult"));
        section("Pediatric dosing", d.optString("pediatric"));
        section("Neonatal dosing", d.optString("neonatal"));
        section("Preparation & administration", d.optString("administration"));
        section("Important precautions", d.optString("cautions"));
        section("Expanded information", d.optString("detail"));
        Button back=button("← Back to drug library"); back.setOnClickListener(v->buildHome()); content.addView(back);
    }
    void section(String h,String body) {
        content.addView(label(h,17,true));
        TextView t=label(body,15,false); t.setBackgroundColor(-1); t.setPadding(12,12,12,12); content.addView(t);
    }
    EditText field(String hint) { EditText e=new EditText(this); e.setSingleLine(true); e.setInputType(8194); e.setHint(hint); content.addView(e); return e; }
    double val(EditText e) { try { return Double.parseDouble(e.getText().toString().trim()); } catch(Exception ex){ return Double.NaN; } }
    void showCalculators() {
        base("Clinical Calculators");
        content.addView(label("IV gravity infusion",19,true));
        content.addView(label("Formula: drops/min = volume (mL) × drop factor (drops/mL) ÷ time (minutes).",14,false));
        EditText volume=field("Total volume (mL)");
        EditText hours=field("Duration (hours)");
        EditText factor=field("Giving-set drop factor (10, 15, 20 or 60 drops/mL)");
        Button calc=button("Calculate drops/min and mL/hour"); content.addView(calc);
        TextView result=label("",18,true); content.addView(result);
        calc.setOnClickListener(v->{
            double V=val(volume), H=val(hours), F=val(factor);
            if(!(V>0&&H>0&&F>0)){ result.setText("Enter positive values in all fields."); return; }
            double mlh=V/H, gtt=V*F/(H*60.0);
            result.setText(String.format(Locale.US,"Flow rate: %.1f mL/hour\nGravity rate: %.0f drops/min",mlh,Math.round(gtt)));
        });
        content.addView(label("Weight-based dose calculator",19,true));
        EditText weight=field("Patient weight (kg)");
        EditText dose=field("Prescribed dose (mg/kg/dose)");
        Button doseCalc=button("Calculate dose in mg"); content.addView(doseCalc);
        TextView doseResult=label("",18,true); content.addView(doseResult);
        doseCalc.setOnClickListener(v->{
            double w=val(weight), d=val(dose);
            if(!(w>0&&d>0)){doseResult.setText("Enter positive weight and dose.");return;}
            doseResult.setText(String.format(Locale.US,"Calculated dose: %.2f mg\nConfirm maximum dose, interval, indication, age group and formulation separately.",w*d));
        });
        content.addView(label("Calculator limitations",16,true));
        content.addView(label("These calculators perform arithmetic only. They do not determine whether a drug, dose, diluent, concentration, route, or infusion duration is clinically appropriate. Independent verification is required, especially for neonates and high-alert medicines.",14,false));
        Button back=button("← Back to home"); back.setOnClickListener(v->buildHome()); content.addView(back);
    }
}